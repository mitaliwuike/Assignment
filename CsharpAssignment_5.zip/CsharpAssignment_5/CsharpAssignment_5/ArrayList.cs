﻿using System;
using System.Collections;

namespace CsharpAssignment_5
{
    class Employee_
    {
        public int emplId { get; set; }
        public string emplName { get; set; }
        public int emplAge { get; set; }
        public decimal empSalary { get; set; }
        public Employee_(int emplId, string emplName, int emplAge, decimal empSalary)
        {
            this.emplId = emplId;
            this.emplName = emplName;
            this.emplAge = emplAge;
            this.empSalary = empSalary;
        }
    }

    class Test
    {
        public static void Main(string[] args)
        {
            ArrayList e = new ArrayList();
            Employee_ e1 = new Employee_(250, "John", 26, 25000);
            Employee_ e2 = new Employee_(356, "Harry", 23, 20000);
            Employee_ e3 = new Employee_(124, "Tom", 21, 15000);
            e.Add(e1);
            e.Add(e2);
            e.Add(e3);
            
            foreach (Employee_ i in e)
            {
                Console.WriteLine("Employee Id : " + i.emplId);
                Console.WriteLine("Employee Name : " + i.emplName);
                Console.WriteLine("Employee Age : " + i.emplAge);
                Console.WriteLine("Employee Salary : " + i.empSalary);
                Console.WriteLine();
                
            }
            Console.WriteLine(e.Count);
            Console.ReadLine();
        }
    }
}