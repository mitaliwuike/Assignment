﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CsharpAssignment_5
{
   
    class ArrayClass
    {
        static void Main(string[] args)
        {
            int[] arr_int = new int[5];
            string[] arr_str = new string[5];
            ArrayList My_array = new ArrayList();
            Console.WriteLine("Enter valu");
            My_array.Add("Mumbai");
            My_array.Add("Delhi");
            My_array.Add("Bangalore");
            My_array.Add("Chenni");
            My_array.Add("Amravati");


            Console.WriteLine("After CopyTo Method: ");

            My_array.CopyTo(arr_str);

            foreach (var elements in My_array)
            {
                Console.WriteLine(elements);
            }
            Console.WriteLine();
            My_array.Sort();

            Console.WriteLine("Sorted Arralist : ");
            foreach (string i in My_array)
            {
                Console.WriteLine(i);
            }
            Console.WriteLine();
            Console.WriteLine("Reverse array List : ");

            My_array.Reverse();

            for (int i = 0; i < My_array.Count; i++)
            {
                Console.WriteLine(My_array[i]);
            }
            Console.WriteLine();

            My_array.Clear();
            Console.WriteLine("After Clear() method the " +
                "number of elements: " + My_array.Count);



            Console.ReadKey();
        }
    }
}
