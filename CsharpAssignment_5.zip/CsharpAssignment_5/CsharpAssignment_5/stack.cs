﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpAssignment_5
{
    public class Data
    {
        public int Id { get; set; }
        public string Name { get; set; }
        public int Salary { get; set; }
       
    }
    
    internal class Program4
    {
        public static void Main(string[] args)
        {
            Data d1 = new Data()
            {
                Id = 201,
                Name = "John",
                Salary = 24000

            };
            Data d2 = new Data()
            {
                Id = 202,
                Name = "Marry",
                Salary = 23000
            };
            Data d3 = new Data()
            {
                Id = 203,
                Name = "Jerry",
                Salary = 14000
            };
            Stack<Data> stack = new Stack<Data>();

            stack.Push(d1);
            stack.Push(d2);
            stack.Push(d3);


            foreach (Data Data in stack)
            {
                Console.WriteLine(Data.Id + " - " + Data.Name + " - " + Data.Salary);
            }
            Console.WriteLine("Items left in the Stack = " + stack.Count);
            try { 
                Data e1 = stack.Pop();
                Console.WriteLine(e1.Id + " - " + e1.Name + " - " + e1.Salary);
            }
            catch (Exception ex)
            {
                Console.WriteLine(ex.Message);

            }

            Console.WriteLine("Items left in the Stack = " + stack.Count);


            Console.ReadKey();

        }
    }
}
