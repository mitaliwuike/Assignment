﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CsharpAssignment_5
{
    class Employee
    {
        public int EmpId { get; set; }
        public string EmpName { get; set; }
        public int EmpAge { get; set; }
        public decimal EmpSalary { get; set; }
        public Employee(int eid, string ename, int eage, decimal esalary)
        {
            EmpId = eid;
            EmpName = ename;
            EmpAge = eage;
            EmpSalary = esalary;
        }
    }

    class Program
    {
        public static void Main(string[] args)
        {
            ArrayList e = new ArrayList();
            Employee e1 = new Employee(250, "John", 26, 25000);
            Employee e2 = new Employee(356, "Harry", 23, 20000);
            Employee e3 = new Employee(124, "Tom", 21, 15000);
            e.Add(e1);
            e.Add(e2);
            e.Add(e3);
            foreach(Employee i in e)
            {
                Console.WriteLine("Employee Id : " + i.EmpId);
                Console.WriteLine("Employee Name : " + i.EmpName);
                Console.WriteLine("Employee Age : " + i.EmpAge);
                Console.WriteLine("Employee Salary : " + i.EmpSalary);
                Console.WriteLine();
            }
            Console.ReadLine();
        }
    }
}