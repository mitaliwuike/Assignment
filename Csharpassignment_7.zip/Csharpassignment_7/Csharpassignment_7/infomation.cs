﻿using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Csharpassignment_7
{
    [Serializable]
    abstract class Employee
    {
        public abstract void getValue();
        public abstract void showValue();
    }
    [Serializable]
    class manager : Employee
    {
        public int empid;
        public string empname;

        public override void getValue()
        {
            Console.WriteLine("Enter Your Employess Id:");
            empid = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Your Employess Name:");
            empname = Console.ReadLine();
        }
        public override void showValue()
        {
            Console.WriteLine("Your Employee Id is {0}", empid);
            Console.WriteLine("Your Employee Name  is {0}", empname);
        }
    }
    [Serializable]
    class MarketingExecutive : Employee
    {
        public int empid;
        public string empname;

        public override void getValue()
        {
            Console.WriteLine("Enter Your Employess Id:");
            empid = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Enter Your Employess Name:");
            empname = Console.ReadLine();
        }
        public override void showValue()
        {
            Console.WriteLine("Your Employee Id is {0}", empid);
            Console.WriteLine("Your Employee Name  is {0}", empname);
        }
    }
    class Program_
    {
        public static void Main(string[] args)
        {
            manager mg = new manager();
            MarketingExecutive me = new MarketingExecutive();

            string path = @"E:\EmployeeInfo.txt";
            FileStream stream = new FileStream(path, FileMode.OpenOrCreate);
            BinaryFormatter formatter = new BinaryFormatter();
            formatter.Serialize(stream, mg);
            Console.WriteLine();
            formatter.Serialize(stream, me);
            Console.WriteLine("Done Sucessfully...");
            stream.Close();
            Console.ReadLine();

        }
    }
}
