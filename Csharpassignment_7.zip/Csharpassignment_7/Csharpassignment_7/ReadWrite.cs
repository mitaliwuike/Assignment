﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO;

namespace Csharpassignment_7
{
    public delegate void DelEventHandler();

    class customer
    {
        public event DelEventHandler add;
        public int AccountNo;
        public string Name;
        public int Balance;
        public void AccInfo()
        {
            Console.Write("Enter Account No : ");
            AccountNo = int.Parse(Console.ReadLine());
            Console.Write("Enter Name : ");
            Name = Console.ReadLine();
            Console.Write("Enter the Balance : ");
            Balance = int.Parse(Console.ReadLine());
        }
    }
    class Program
    {

        static void Main(string[] args)
        {
            customer c = new customer();
            DelEventHandler d = new DelEventHandler(c.AccInfo);
            c.add += new DelEventHandler(c.AccInfo);
            d();
            string path = @"E:\CustomerInfo.txt";
            using (FileStream f = new FileStream(path, FileMode.Append,FileAccess.Write))
            {
                using(StreamWriter s = new StreamWriter(f))
                {
                    s.WriteLine("Account no " + c.AccountNo);
                    s.WriteLine("Name : " + c.Name);
                    s.WriteLine("Balance : " + c.Balance);
                }
                Console.WriteLine("Information Add Sucessfully...");

            }
            using (FileStream f = new FileStream(path, FileMode.Open, FileAccess.Read))
            {
                using (StreamReader s = new StreamReader(f))
                {
                    string line = "";
                    while((line = s.ReadLine()) != null)
                    {
                        Console.WriteLine(line);
                    }
                    Console.WriteLine();
                }

            }

            Console.ReadLine();
        }
    }
}