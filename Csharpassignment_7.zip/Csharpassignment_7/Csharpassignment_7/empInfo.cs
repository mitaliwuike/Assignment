﻿using System;
using System.IO;
using System.Runtime.Serialization.Formatters.Binary;

namespace Csharpassignment_7
{
    [Serializable]
    class Manager
    {

        public int empId;
        public string empName;
        public int empSalary;
        public Manager()
        {
            Console.Write("Enter Your Employess Id : ");
            empId = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter Your Employess Name : ");
            empName = Console.ReadLine();
            Console.Write("Enter Your Employess Salary : ");
            empSalary = Convert.ToInt32(Console.ReadLine());
        }

    }

    class Serilizable
    {
        public static void Main(string[] args)
        {
            string filePath = @"E:\Information.txt";
            FileStream stream = new FileStream(filePath, FileMode.OpenOrCreate);
            BinaryFormatter formatter = new BinaryFormatter();

            Manager m = new Manager();
            formatter.Serialize(stream, m);
            stream.Close();
            Console.WriteLine("Serialize Done.");

            FileStream ft = new FileStream(filePath, FileMode.OpenOrCreate);
            BinaryFormatter form = new BinaryFormatter();

            Manager s = (Manager)form.Deserialize(ft);
            Console.WriteLine("Rollno: " + s.empId);
            Console.WriteLine("Name: " + s.empName);
            Console.WriteLine("Name: " + s.empSalary);
            Console.WriteLine("Serialize Done.");
            stream.Close();
            Console.ReadKey();

        }
    }
}
