﻿using System;
using System.IO;

namespace Csharpassignment_7
{
    class File
    {
        public static void Main(string[] args)
        {
            var lines = System.IO.File.ReadAllLines(@"E:\file.txt");
            for (var i = 0; i < lines.Length; i += 1)
            {
                var line = lines[i];
                Console.WriteLine(line);
            }
            Console.WriteLine("\nFolders in This Drive : \n\n");
            DirectoryInfo di = new DirectoryInfo("c:\\");
            DirectoryInfo[] diArr = di.GetDirectories();
            foreach (DirectoryInfo dri in diArr)
                Console.WriteLine(dri.Name);
            Console.ReadKey();
        }

      
    }
}
