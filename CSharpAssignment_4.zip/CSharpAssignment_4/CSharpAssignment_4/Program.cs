﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpAssignment_4
{
    internal class Program
    {
        static void Main(string[] args)
        {
            Stack stack = new Stack();
            Console.Write("Enter the stack size : ");
            int size = int.Parse(Console.ReadLine());
        start:
            Console.Write("What you want ? Push or pop (for exit enter 0 ) : ");
            string Result = Console.ReadLine();
            if ("PUSH" == Result.ToUpper())
            {
                try
                {
                    if (size > stack.Count)
                    {
                        try
                        {
                            Console.Write("Enter the Push value : ");
                            int Push_value = int.Parse(Console.ReadLine());
                            stack.Push(Push_value);
                            goto start;
                        }
                        catch(Exception ex)
                        {
                            Console.WriteLine(ex.Message);
                            goto start;
                        }
                        
                    }
                    else
                    {
                        throw new Exception("Stack is Full");
                    }
                }
                catch(Exception ex){
                    Console.WriteLine(ex.Message);
                    goto start;
                }

            }
            else if("POP" == Result.ToUpper()){
                try
                {
                    if (stack.Count > 0)
                    {
                        stack.Pop();
                        goto start;
                    }
                    else
                    {
                        throw new Exception("Stack is Empty");
                    }
                }
                catch (Exception ex)
                {
                    Console.WriteLine(ex.Message);
                    goto start;
                }
            }
            else
            {
                Console.WriteLine("Thank You for visiting...");
            }


            Object[] arr = stack.ToArray();
            Console.Write("Stack : ");


            foreach (Object str in arr)
            {
                Console.WriteLine(str + " ");
            }

            Console.ReadLine();



        }
    }
}
