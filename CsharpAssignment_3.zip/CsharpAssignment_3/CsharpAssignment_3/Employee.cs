﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CsharpAssignment_3
{
    class Employee
    {
        public int emp_id, emp_salary, emp_travel;
        public string emp_name;
        public void getValue()
        {
            Console.Write("Enter Employee id : ");
            emp_id = int.Parse(Console.ReadLine());
            Console.Write("Enter Employee Name : ");
            emp_name = Console.ReadLine();
        }
        public void getSalary()
        {
            Console.Write("Enter Employee Salaary : ");
            emp_salary = int.Parse(Console.ReadLine());
        }
        public void getKm()
        {
            Console.Write("How many kilometer travel : ");
            emp_travel = int.Parse(Console.ReadLine());
        }
        public void display()
        {
            Console.WriteLine("---Employee Details---");
            Console.WriteLine("Employee id : " + emp_id);
            Console.WriteLine("Employee Name : " + emp_name);
        }
    }
    class Manager : Employee
    {
        public void CalculationSalary()
        {
            int PF = 750;
            double petrol = (emp_salary * 8) / 100;
            double food = (emp_salary * 13) / 100;
            double other = (emp_salary * 3) / 100;
            double GrossSalary = emp_salary + petrol + food + other;
            double netSalary = emp_salary - PF;

            Console.WriteLine("Employee Gross Salary : " + GrossSalary + "/-");
            Console.WriteLine("Employee Net Salary : " + netSalary + "/-");
        }

    }
    class MarketingExecutive : Employee
    {
        int emp_salary = 20000;
        public void CalculationSalary()
        {
            int PF = 750;
            int tele_allowance = 1000;
            double GrossSalary = emp_salary + (emp_travel / 5) + tele_allowance;
            double netSalary = GrossSalary - PF;
            Console.WriteLine("Employee Gross Salary : " + GrossSalary + "/-");
            Console.WriteLine("Employee Net Salary : " + netSalary + "/-");
        }

    }
    class main
    {
        public static void Main(string[] args)
        {
            Manager manager = new Manager();
            manager.getValue();
            manager.getSalary();
            Console.WriteLine();
            manager.display();
            manager.CalculationSalary();

            Console.WriteLine();

            MarketingExecutive marketingExecutive = new MarketingExecutive();
            marketingExecutive.getValue();
            marketingExecutive.getKm();
            Console.WriteLine();
            manager.display();
            marketingExecutive.CalculationSalary();

            Console.ReadKey();

        }
    }
}
