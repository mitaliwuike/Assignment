﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using CSharpAssignment_2;


namespace Details
{
    class Employee_details
    {
        static void Main(string[] args)
        {
            Employee employee = new Employee();
            Console.WriteLine("Enter Employee Details : ");
            Console.Write("Employee ID : ");
            int emp_id = int.Parse(Console.ReadLine());
            Console.Write("Employee Name : ");
            string emp_name = Console.ReadLine();
            Console.Write("Employee Salary : ");
            int emp_salary = int.Parse(Console.ReadLine());
            double Result = employee.getValue(emp_salary);
            double Calculation_salary = employee.calculationSalary(Result);
            Console.WriteLine("Employee net Salary : " + Calculation_salary);
            Console.ReadLine();
        }
    }
}
