﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpAssignment_2
{
    internal class Employee
    {
        double salary, HRA, TA, DA, PF, TDS, NetSalary, GrossSalary;
        public double getValue( double e_salary)
        {
            salary = e_salary;
           
            if (salary < 5000)
            {
                HRA = (salary * 10) / 100;
                TA = (salary * 5) / 100;
                DA = (salary * 15) / 100;
                GrossSalary = salary + HRA + TA + DA;
            }
            else if (salary > 5000 && salary <= 10000)
            {
                HRA = (salary * 10) / 100;
                TA = (salary * 5) / 100;
                DA = (salary * 15) / 100;
                GrossSalary = salary + HRA + TA + DA;
            }
            else if (salary > 10000 && salary <= 15000)
            {
                HRA = (salary * 10) / 100;
                TA = (salary * 5) / 100;
                DA = (salary * 15) / 100;
                GrossSalary = salary + HRA + TA + DA;
            }
            else if (salary > 20000)
            {
                HRA = (salary * 10) / 100;
                TA = (salary * 5) / 100;
                DA = (salary * 15) / 100;
                GrossSalary = salary + HRA + TA + DA;
            }
            return GrossSalary;

        }
        public Double calculationSalary(double Gross_salary)
        {
            GrossSalary = Gross_salary;
            PF = (GrossSalary * 10) / 100;
            TDS = (GrossSalary * 18) / 100;
            NetSalary = GrossSalary - (PF - TDS);
            return NetSalary;
        }
    }
}
