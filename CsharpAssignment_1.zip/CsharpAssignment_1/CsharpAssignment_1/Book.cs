﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace CSharpAssignment_1
{
    class Books
    {
        struct Book
        {
            private string title;
            private string type;
            private int price;
            private int id;
            public void display(int id, string type, string title, int price)
            {
                Console.WriteLine("--Books Details--");
                Console.WriteLine("Book Id : " + id);
                Console.WriteLine("Book Type : " + type);
                Console.WriteLine("Book Title : " + title);
                Console.WriteLine("Book Price : " + price + "/-");
            }
        };
        public static void Main(string[] args)
        {

            Console.WriteLine("Enter the Book Id : ");
            int book_id = int.Parse(Console.ReadLine());
            Console.WriteLine("Enter the Book of type : ");
            string book_type = Console.ReadLine();
            Console.WriteLine("Enter the Book of Author : ");
            string book_title = Console.ReadLine();
            Console.WriteLine("Enter the Book Price : ");
            int book_price = int.Parse(Console.ReadLine());
            Book book = new Book();
            book.display(book_id, book_type, book_title, book_price);
            Console.ReadKey();
        }
    }
}
