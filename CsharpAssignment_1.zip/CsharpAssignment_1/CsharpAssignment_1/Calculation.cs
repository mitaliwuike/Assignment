﻿using System;
namespace CShrapAssignment_1
{
    internal class Calculator
    {
        static void Main(string[] args)
        {
            Console.Write("Enter the first number : ");
            int num1 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the second number : ");
            int num2 = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the operator +, -, *, /, % : ");
            string Operator = Console.ReadLine();
            switch (Operator)
            {
                case "+":
                    Console.WriteLine("Addition : " + (num1 + num2));
                    break;
                case "-":
                    Console.WriteLine("Substraction : " + (num1 - num2));
                    break;
                case "*":
                    Console.WriteLine("Multiplication : " + (num1 * num2));
                    break;
                case "/":
                    Console.WriteLine("Division : " + (num1 / num2));
                    break;
                case "%":
                    Console.WriteLine("Modulus : " + (num1 % num2));
                    break;
                default:
                    Console.WriteLine("Operator is invalid");
                    break;
            }
        }
    }
}