﻿using System;

namespace CsharpAssignment_1
{
    class Swapping
    {
        public static void swap(int x, int y)
        {
            x = x + y;
            y = x - y;
            x = x - y;
            Console.WriteLine("After swapping X = " + x + " y = " + y);
        }
        public static void Main(string[] args)
        {
            Console.Write("Enter the X value : ");
            int x = Convert.ToInt32(Console.ReadLine());
            Console.Write("Enter the Y value : ");
            int y = Convert.ToInt32(Console.ReadLine());
            Console.WriteLine("Before swapping X = " + x + " y = " + y);
            swap(x, y);
        }

    }
}