﻿using System;

public class CSharpassignment_1
{
    internal class Area
    {
       
        public void Calculate(int r)
        {
            float PI = 3.14f;
            float area = PI * r * r;
            float circumference = 2 * PI * r;
            Console.WriteLine("Area od circle : " + area);
            Console.WriteLine("Circumference of circle : " + circumference);
        }
        public static void Main(string[] args)
        {
            Console.Write("Enter the radius of circle : ");
            int radius = Convert.ToInt32(Console.ReadLine());
            Area area = new Area();
            area.Calculate(radius);
            Console.ReadLine();
        }
    }
}