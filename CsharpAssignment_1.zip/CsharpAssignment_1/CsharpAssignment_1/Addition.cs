﻿using System;

namespace CsharpAssignment_1
{
    class Addition
    {
        public static void Main(string[] args)
        {
            int[] array = { 2, 5, 3, 4 };
            int array_length = array.Length;
            Console.WriteLine("Sum of given array is " + sum(array, array_length));
            Console.ReadKey();
        }
        static int sum(int[] array, int array_length)
        {
            int sum = 0;
            for (int i = 0; i < array_length; i++)
            {
                sum = sum + array[i];
            }
            return sum;
        }
    }
}