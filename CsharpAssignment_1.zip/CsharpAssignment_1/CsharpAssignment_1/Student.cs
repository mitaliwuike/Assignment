﻿using System;

namespace CsharpAssignment_1
{
    public class Student
    {
        public static void Main(string[] args)
        {
            int size, hightest_mark = 0;
            int[] mark = new int[50];

            Console.Write("Enter th number of student : ");
            size = Convert.ToInt32(Console.ReadLine());

            Console.Write("Enter the student average marks :\n");
            for (int i = 0; i < size; i++)
            {
                mark[i] = Convert.ToInt32(Console.ReadLine());
                if (mark[i] > hightest_mark)
                {
                    hightest_mark = mark[i];
                }
            }

            Console.Write("\nThe Highest Marks Is: {0} ", hightest_mark);
            Console.ReadKey();
        }
    }
}