﻿using System;

namespace CSharpAssignment_6
{
    public delegate void DeleManager();
    public delegate void DeleMarketing();

    class Employee_
    {
        public int emp_id, emp_salary, emp_travel;
        public string emp_name;
        public void getValue()
        {
            Console.Write("Enter Employee id : ");
            emp_id = int.Parse(Console.ReadLine());
            Console.Write("Enter Employee Name : ");
            emp_name = Console.ReadLine();
        }
        public void getSalary()
        {
            Console.Write("Enter Employee Salary : ");
            emp_salary = int.Parse(Console.ReadLine());
        }
        public void getKm()
        {
            Console.Write("How many kilometer travel : ");
            emp_travel = int.Parse(Console.ReadLine());
        }
        public void display()
        {
            Console.WriteLine("---Employee Details---");
            Console.WriteLine("Employee id : " + emp_id);
            Console.WriteLine("Employee Name : " + emp_name);
        }
    }
    class Manager_ : Employee_
    {
        public void CalculationSalary()
        {
            int PF = 750;
            double petrol = (emp_salary * 8) / 100;
            double food = (emp_salary * 13) / 100;
            double other = (emp_salary * 3) / 100;
            double GrossSalary = emp_salary + petrol + food + other;
            double netSalary = emp_salary - PF;

            Console.WriteLine("Employee Gross Salary : " + GrossSalary + "/-");
            Console.WriteLine("Employee Net Salary : " + netSalary + "/-");
        }

    }
    class MarketingExecutive_ : Employee_
    {
        int emp_salary = 20000;
        public void CalculationSalary()
        {
            int PF = 750;
            int tele_allowance = 1000;
            double GrossSalary = emp_salary + (emp_travel / 5) + tele_allowance;
            double netSalary = GrossSalary - PF;
            Console.WriteLine("Employee Gross Salary : " + GrossSalary + "/-");
            Console.WriteLine("Employee Net Salary : " + netSalary + "/-");
        }

    }
    class Program
    {
        static void Main(string[] args)
        {
            Manager_ m = new Manager_();
            DeleManager dm = new DeleManager(m.getValue);

            dm = dm + m.getSalary + m.display + m.CalculationSalary;
            dm();
            Console.WriteLine();
            MarketingExecutive_ me = new MarketingExecutive_();
            DeleMarketing mk = new DeleMarketing(me.getValue);

            mk = mk + me.getKm + me.display + me.CalculationSalary;
            mk();




            Console.ReadKey();

        }
    }
}
