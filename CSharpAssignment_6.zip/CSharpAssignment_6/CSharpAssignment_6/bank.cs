﻿using System;

namespace oop3
{
    class bank
    {
        private double balance = 100000;

        public double bal
        {
            get { return balance; }
            set { balance = value; }
        }
    }
    public delegate void DelegateFunction(int x);

    class operation
    {
        bank i = new bank();
        string name;
        int account;
        double withdrawAmount, depositeAmount, totalBalance;

        public event DelegateFunction UnderBalance;
        public event DelegateFunction ZeroBalance;
        public void Insufficient(int x)
        {
            UnderBalance(x);
        }
        public void DepositeAmount(int x)
        {
            ZeroBalance(x);
        }

        public void info()
        {
            Console.WriteLine("Enter Name of the depositor:");
            name = Console.ReadLine();
            Console.WriteLine("Enter Account Number:");
            account = Convert.ToInt32(Console.ReadLine());
        }
        public void display()
        {
            Console.WriteLine("Name of the depositor: " + name);
            Console.WriteLine("Account Number: " + account);
        }

        public void deposite(int x)
        {
            depositeAmount = x;
            totalBalance = i.bal + depositeAmount;
            Console.WriteLine();
            Console.WriteLine("Total Balance amount in the account: " + totalBalance);
        }
        public void withdraw(int x)
        {
            withdrawAmount = x;

            if (withdrawAmount <= i.bal)
            {
                totalBalance = i.bal - withdrawAmount;

                Console.WriteLine();
                Console.WriteLine("After Withdraw Amount balnace is : " + totalBalance);
            }
            else
            {
                Console.WriteLine("\n\nWithdraw Ammount does not Exist your Account. Your current balance is " + i.bal);
            }
        }

    }

    class Program
    {

        static void Main(string[] args)
        {
            char ans;
            operation k = new operation();
            int num;
        start:
            Console.WriteLine("Please Select Any Function.");
            Console.WriteLine("\nPress 1 for Deposit an Amount. \nPress 2 for Withdraw an Amount.");
            num = Convert.ToInt32(Console.ReadLine());
            k.info();
            switch (num)
            {
                case 1:
                    Console.WriteLine("Enter Deposit Amount:");
                    int depositeAmount = int.Parse(Console.ReadLine());
                    k.ZeroBalance += new DelegateFunction(k.deposite);
                    k.DepositeAmount(depositeAmount);
                    break;
                case 2:
                    Console.WriteLine("Enter Withdraw Amount:");
                    int withdrawAmount = int.Parse(Console.ReadLine());
                    k.UnderBalance += new DelegateFunction(k.withdraw);
                    k.Insufficient(withdrawAmount);
                    break;
                default:
                    Console.WriteLine("Invalid Selection!!!");
                    break;
            }
            Console.WriteLine("\nDo you want to continue this program ? (y / n)");
            ans = Convert.ToChar(Console.ReadLine());
            if (ans == 'y')
            {
                goto start;
            }

            Console.ReadKey();

        }

    }

}